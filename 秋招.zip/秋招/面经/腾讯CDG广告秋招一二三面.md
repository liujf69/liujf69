# 一面
# 1. 介绍一下SoRa的结构和训练方法
<div align=center>
<img src="./Imgs/open-sora1.png", width = 400/>
</div>

<div align=center>
<img src="./Imgs/open-sora2.png", width = 600/>
</div>

```
Open-SoRa主要用于文生视频，其主要由三个核心组件组成，第一个是视觉编码器VAE，第二个是文本编码器T5，第三个是时空DIT网络。
VAE将输入的视频帧编码成视觉特征，
大模型T5将文本编码成文本特征，
视觉特征和文本特征会输入到时空DIT网络，视觉特征在时空DIT中会经过时序注意力机制进行建模。
由于文本特征是一个驱动条件，所以视频特征会经过Cross-Attention机制来融合来自文本的特征，从而实现文生视频。
```

# 2. 手撕VAE结构

# 3. VAE的重参数技巧

# 4. 介绍一下SVD模型

# 5. 结合代码介绍一下DiT结构

6. VAE和VQ-VAE的区别，分别适用于哪里？

# 二面
# 1. maxpooling如何反向传播？
<div align=center>
<img src="./Imgs/maxpooling.png", width = 600/>
</div>

# 2. Transformer为什么可以堆得很深，又没有梯度消失这些问题？
计算Attention机制时，Attention Scores会除以 $\sqrt{d_{k}}$，确保分布的方差一致，使得训练更稳定。

# 3. Transformer的结构？Encoder和Decoder的区别？
[Transformer模型中的Encoder和Decoder的理解与实现](https://zhuanlan.zhihu.com/p/702819315)
<div align=center>
<img src="./Imgs/Encoder_Decoder.png", width = 600/>
<img src="./Imgs/Encoder_Decoder2.png", width = 600/>
</div>

# 4. 相对位置编码的好处？
[https://zhuanlan.zhihu.com/p/584488007](https://zhuanlan.zhihu.com/p/584488007)
```
    绝对位置编码为每一个token分配一个绝对位置编码flag，对于长序列而言，这个flag会超出长度限制（512）。
    绝对位置编码一般在输入层面进行作用，而绝对位置编码一般在网络结构层面进行处理（计算Attention时）。
```
<div align=center>
<img src="./Imgs/Relative_position_embedding.png", width = 600/>
</div>

# 三面
# 介绍一下在腾讯的工作？落地场景


