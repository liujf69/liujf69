# 1. DeepSpeed中ZeRo的原理
ZeRO是一种针对大规模分布式深度学习的新型内存优化技术。<br />
在DeepSpeed下，ZeRO训练支持四个Stage：Zero-0、Zero-1、Zero-2、Zero-3。<br />
四个Stage的区别如下：
```
# Zero-0、Zero-1、Zero-2和Zero-3速度依次降低，所需显存也依次降低。
Zero-0: 不使用所有类型的分片，仅使用DeepSpeed作为DDP，速度最快，所需显存最高。
Zero-1: 切分优化器状态，分片到每个数据并行的工作进程(每个GPU)下。
Zero-2: 切分优化器状态 + 梯度，分片到每个数据并行的工作进程(每个GPU)下。
Zero-3: 切分优化器状态 + 梯度 + 模型参数，分片到每个数据并行的工作进程(每个GPU)下
```