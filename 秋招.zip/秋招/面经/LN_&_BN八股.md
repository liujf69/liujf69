# BN和LN的区别
[参考链接1](https://zhuanlan.zhihu.com/p/647813604) <br />
[参考链接2] (https://zhuanlan.zhihu.com/p/311165133) <br />

<div align=center>
<img src="./Imgs/BN_LN1.png", width = 600/>
</div>

# 为什么RNN或Transformer要用Layer Normalization
<div align=center>
<img src="./Imgs/LN1.png", width = 600/>
</div>

# BN的公式和参数量
<div align=center>
<img src="./Imgs/BN1.png", width = 600/>
</div>

# BN的作用
[参考链接3](https://www.zhihu.com/search?type=content&q=BN%E7%9A%84%E4%BD%9C%E7%94%A8) <br />
<div align=center>
<img src="./Imgs/BN2.png", width = 600/>
</div>
