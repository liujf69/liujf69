# LoRA的原理
通过两个低秩矩阵A和B来模拟原模型的参数，在微调时固定原模型的参数，而只去FineTune LoRA层。

# LoRA两个超参数
带LoRA层的模型输出：$Wx + \frac{\alpha}{r}BAx$ <br />
超参数r的取值一般是4, 8, 16。 <br />
超参数 $\alpha$ 的取值一般是超参数r值的大小。<br />
LoRA的参数量随超参数r的增加而线性增加。<br />

# 矩阵参数初始化
矩阵A的参数由随机高斯数进行初始化。<br />
矩阵B的参数初始化为0。<br />
因此在训练开始时，模型会沿用原模型的参数，可以很好地复用原模型的能力。

# 添加LoRA层不会增加额外的推理时间
<div align=center>
<img src="./Imgs/LoRA1.png", width = 400/>
</div>

# SVD中在哪些层添加了LoRA层？
```python
unet_lora_config = LoraConfig(
    r = 64, 
    lora_alpha = 64, # scaling = lora_alpha / r
    init_lora_weights = "gaussian", 
    target_modules = ["to_q","to_k","to_v","to_out.0"],
    lora_dropout = 0.1
)
```
在SVD中，对UNet网络的**注意力层**添加了LoRA层，具体就是 **"to_q"**, **"to_k"**, **"to_v"**, **"to_out.0"**。

# LoRA一般微调哪些参数？
理论上，全连接层都可以使用LoRA进行微调。<br />
一般而言，LoRA只对Self-Attention中的Wq, Wk, Wv和Wo进行微调。