1. 训练稳定性问题 <br />
    相比于GAN模型，Diffusion模型具有严谨的数学理论推导，且训练更为稳定。<br />
    GAN模型由于需要同时训练判别器（先训练）和生成器（后训练），导致其存在对抗的性质，从而导致GAN模型非常难以训练。<br />
2. Scaling Up的问题
    Transformer-based的模型，由于自回归需要使用Attention机制，导致当模型变大或者图片分辨率变高时，Attention机制的花销会非常大，限制了模型的Scaling Up。<br />
    同理，由于GAN模型非常难以训练，当模型需要Scaling Up时会使得训练更加困难。
3. VAE的问题
    VAE存在模糊的问题，VAE将图片进行压缩，可能存在压缩过度的问题，导致信息或特征丢失，同时VAE是一步生成，其生成质量不如Diffusion的多步生成操作。