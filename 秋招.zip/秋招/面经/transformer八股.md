# Attention为什么要除以$\sqrt{d_k}$
<div align=center>
<img src="./Imgs/Trans1.png", width = 600/>
</div>

# Transformer十问
[Transformer十问](https://zhuanlan.zhihu.com/p/682585974)