# DeekSeek-VL
[论文](https://arxiv.org/pdf/2403.05525)

<div align=center>
<img src="./Imgs/DeekSeek-VL.png", width = 600/>
</div>

```
DeekSeek-VL主要由三个核心模块进行组成。
第一个模块是混合视觉编码器，主要由SAM-B和SigLip两个视觉编码器组成，其作用是对输入的图片进行编码。
第二个模块是视觉语言Adaptor（Vision-Language Adaptor），其作用是将编码后的图片特征投影到语言空间中。
第三个模块是一个大语言模型，其接收来自文本和视觉的特征进行自回归预测。

DeekSeek-VL分三个阶段训练模型。
第一个阶段只去训练视觉语言Adaptor，
第二个阶段会同时训练视觉语言Adaptor和大语言模型，
第三个阶段通过指令微调的方法，同时微调混合视觉编码器、视觉语言Adaptor和下游的大语言模型DeepSeek-VL。
```

# Video-LLaMa
[论文](https://arxiv.org/pdf/2306.02858v2)

<div align=center>
<img src="./Imgs/video_LLaMA.png", width = 600/>
</div>

```
Video-LLama主要由三个模块组成：
第一块是视觉语言分支（Vision-Language Branch），主要是利用VIT和Q-Former对视频帧进行特征编码，然后使用一个线性层将视觉特征投影到语言空间中。
第二块是音频语言分支（Audio-Language Branch），主要是利用Imagebind对音频信号进行特征编码，然后同样使用一个线性层将音频特征投影到语言空间中。
第三块是一个大语言模型（Vicuna/LLaMA），首先将前面两块得到的视觉特征和音频特征进行拼接，然后输入到大语言模型中进行自回归预测。
```

# GLM-4V

<div align=center>
<img src="./Imgs/GLM-4V.png", width = 600/>
</div>

```
GLM-4V主要由三个模块组成：
第一块是视觉编码器，使用EVA2CLIPModel来将图片进行特征编码。
第二块是MLP-Adaptor，通过MLP将视觉特征投影到语言空间中。
第三块是一个大语言模型（GLM-4），首先将前面视觉embedding和文本embedding进行拼接，然后输入到大语言模型中进行自回归预测。
```

# MiniGPT-4
<div align=center>
<img src="./Imgs/MiniGPT-4.png", width = 600/>
</div>

```
MiniGPT-4主要由三个模块组成：
第一块是视觉编码器，主要是使用Q-Former或VIT来将图片进行特征编码。
第二块是线性层，通过线性层将视觉特征投影到语言空间中。
第三块是一个大语言模型（Vicuna或LLaMA-2），首先将前面视觉embedding和文本embedding进行拼接，然后输入到大语言模型中进行自回归预测。
```

# LLaVA
<div align=center>
<img src="./Imgs/LLaVA.png", width = 600/>
</div>

```
LLaVA主要由三个模块组成：
第一块是视觉编码器，主要是使用CLIP的视觉编码器ViT-L/14来将图片进行特征编码。
第二块是线性层，通过线性层将视觉特征投影到语言空间中。
第三块是一个大语言模型（LLaMA），首先将前面视觉embedding和文本embedding进行拼接，然后输入到大语言模型中进行自回归预测。

LLaVA的训练会分两步：
第一步冻结视觉编码器和大语言模型，只训练线性投影层。
第二步会冻结视觉编码器，然后同时训练线性投影层和大语言模型。
```

# BLIP
<div align=center>
<img src="./Imgs/BLIP.png", width = 600/>
</div>

<div align=center>
<img src="./Imgs/BLIP2.png", width = 600/>
</div>

[BLIP损失函数代码实现](https://zhuanlan.zhihu.com/p/699507603)
```
BLIP是一个混合结构，使用视觉编码器和文本编码器对图像和文本进行特征编码，可以同时解决三类任务：
1. 图文对齐，主要使用图文对比损失（ITC）进行约束。
2. 图文匹配，主要使用图文匹配损失（ITM）进行约束，ITM损失会使用ITC损失得到的相似度，然后转换为二分类问题，通过交叉熵进行计算。
3. 语言建模，主要使用语言建模损失（LM）进行约束，通过自回归的手段生成下一个token，并使用交叉熵进行损失的计算。
```

# BLIP2
<div align=center>
<img src="./Imgs/BLIP-2.png", width = 600/>
</div>

```
模型结构主要由三部分构成：Image encoder、Q-Former、LLMs，其中Q-Former是重点，并且采用两阶段的训练策略。
第一阶段冻结Image Encoder的参数，训练Queries和Q-Former，让Queries能够将Image Encoder中提取的原始图像特征，转化为和文本特征很接近的特征。
第一阶段的目的是将图像特征拉近到文本特征，这也是BLIP-2的核心创新点。
第二阶段冻结LLMs的参数，训练Queries和Q-Former，使得模型能够获取强大的zero-shot能力和图像生文本的能力
```
