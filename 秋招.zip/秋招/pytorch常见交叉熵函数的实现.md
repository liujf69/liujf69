# 1. nn.CrossEntropyLoss()
计算公式如下：
$$Loss(x, class) = -log(\frac{e^{x[class]}}{\sum_{i}e^{x[i]}}) = -x[class] + log(\sum_{i}e^{x[i]})$$
代码实现如下：
```python
import torch
import torch.nn as nn
import math
import numpy as np

def cross_entorpy(logits, labels):
    loss = 0
    batch = len(labels)
    for b_idx in range(batch):
        hou = 0
        for j in logits[b_idx]: # 计算累加部分
            hou += np.exp(j)
        loss += -logits[b_idx][labels[b_idx]] + np.log(hou) # -logits[b_idx][labels[b_idx]]表示计算-x[class]
    return np.around(loss / batch, 4) # 保留四位小数

if __name__ == "__main__":
    entroy = nn.CrossEntropyLoss()
    logits = torch.Tensor([[0.1234, 0.5555,0.3211], [0.1234, 0.5555,0.3211], [0.1234, 0.5555,0.3211]])
    labels = torch.tensor([0, 1, 2])
    loss1 = entroy(logits, labels) # 调用pytorch接口
    print("loss1: ", loss1) # tensor(1.1142)
    
    logits = np.array(logits)
    labels = np.array(labels)
    loss2 = cross_entorpy(logits, labels) # 调用自定义函数
    print("loss2: ", loss2) # 1.1142
    
    print("All Done!")
```

# 2. nn.BCELoss()
计算公式如下：
$$Loss(x, y) = -\frac{1}{n}\sum_{i}^{n}(y_{i}*ln(x_{i}) + (1-y_{i})*ln(1 - x_{i}))$$
代码实现如下：
```python
import torch
import torch.nn as nn
import math
import numpy as np

def BCE_loss(logits, labels):
    func = nn.Sigmoid()
    logits = func(logits)
    batch = logits.shape[0]
    Num_class = logits.shape[1]
    total_loss = 0
    for b_idx in range(batch):
        single_sample_loss = 0
        for j in range(Num_class):
            single_sample_loss += labels[b_idx][j].item() * math.log(logits[b_idx][j].item()) + (1 - labels[b_idx][j].item()) * math.log(1 - logits[b_idx][j].item())
        total_loss += single_sample_loss / Num_class
        
    loss = -1 * (total_loss / batch)
    return np.around(loss, 4)        

if __name__ == "__main__":
    BCEloss = nn.BCELoss()
    func = nn.Sigmoid()
    logits = torch.Tensor([[1.1234, 1.5555, 1.3211], [1.1234, 1.5555, 1.3211], [1.1234, 1.5555, 1.3211]])
    labels = torch.Tensor([[1, 0, 0], [0, 1, 0], [0, 0, 1]]) # 转换成one-hot的形式
    loss1 = BCEloss(func(logits), labels) # 调用nn.BCELoss()时，logits的数值必须在区间(0, 1)之间
    print("loss1: ", loss1) # tensor(1.1254)
    
    loss2 = BCE_loss(logits, labels)
    print("loss2: ", loss2) # 1.1254
    
    print("All Done!")
```

# 3.nn.BCEWithLogitsLoss()
计算公式如下：
$$Loss(x, y) = -\frac{1}{n}\sum_{i}^{n}(y_{i}*ln(x_{i}) + (1-y_{i})*ln(1 - x_{i}))$$
nn.BCEWithLogitsLoss() 和 nn.BCELoss()的区别在于nn.BCEWithLogitsLoss()自带Sigmoid()函数来处理输入。

代码实现如下：
```python
import torch
import torch.nn as nn
import math
import numpy as np

def BCE_loss(logits, labels):
    func = nn.Sigmoid()
    logits = func(logits)
    batch = logits.shape[0]
    Num_class = logits.shape[1]
    total_loss = 0
    for b_idx in range(batch):
        single_sample_loss = 0
        for j in range(Num_class):
            single_sample_loss += labels[b_idx][j].item() * math.log(logits[b_idx][j].item()) + (1 - labels[b_idx][j].item()) * math.log(1 - logits[b_idx][j].item())
        total_loss += single_sample_loss / Num_class
        
    loss = -1 * (total_loss / batch)
    return np.around(loss, 4)        

if __name__ == "__main__":
    BCEWithLogitsLoss = nn.BCEWithLogitsLoss() # 自带Sigmoid()函数
    logits = torch.Tensor([[1.1234, 1.5555, 1.3211], [1.1234, 1.5555, 1.3211], [1.1234, 1.5555, 1.3211]])
    labels = torch.Tensor([[1, 0, 0], [0, 1, 0], [0, 0, 1]]) # 转换成one-hot的形式
    loss1 = BCEWithLogitsLoss(logits, labels) # 调用nn.BCELoss()时，logits的数值必须在区间(0, 1)之间
    print("loss1: ", loss1) # tensor(1.1254)
    
    loss2 = BCE_loss(logits, labels)
    print("loss2: ", loss2) # 1.1254
    
    print("All Done!")
```
