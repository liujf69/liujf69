import torch
import torch.nn as nn
import torch.nn.functional as F

class Attention(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, num_heads: int):
        super(Attention, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.num_heads = num_heads
        self.head_dim = self.output_dim // self.num_heads
        self.scale = torch.sqrt(torch.FloatTensor([self.head_dim]))
        
        self.query = nn.Linear(self.input_dim, self.output_dim)
        self.key = nn.Linear(self.input_dim, self.output_dim)
        self.value = nn.Linear(self.input_dim, self.output_dim)
        
    def forward(self, x: torch.Tensor):
        B, L, _ = x.shape
        # B L C -> B L Num_head head_dim -> B Num_head L head_dim
        q = self.query(x).reshape(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.key(x).reshape(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.value(x).reshape(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        
        scores = torch.matmul(q, k.transpose(-1, -2)) / self.scale
        scores = F.softmax(scores, dim = -1) # B Num_head L L
        
        output = torch.matmul(scores, v)
        output = output.transpose(1, 2).reshape(B, L, self.output_dim)
        return output
    
if __name__ == "__main__":
    B = 2
    L = 3
    input_dim = 4
    output_dim = 16
    num_heads = 2
    
    demo = Attention(input_dim = input_dim, output_dim = output_dim, num_heads = num_heads)
    x = torch.rand(B, L, input_dim)
    output = demo(x)
    print("output.shape: ", output.shape)
    
    print("All Done!")