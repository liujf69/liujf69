import torch
import torch.nn.functional as F
  
# 第一种写法，分母不包含正样本
def info_nce_loss(anchor_features, positive_features, temperature):
    batch_size, feature_dim = anchor_features.shape # B C
 
    # L2归一化
    anchor_normalized = F.normalize(anchor_features, dim = 1) # B C
    positive_normalized = F.normalize(positive_features, dim = 1) # B C
 
    # 计算锚点和正样本之间的相似度（余弦相似度）
    positive_logits = torch.einsum('nc,nc->n', [anchor_normalized, positive_normalized]).unsqueeze(1) / temperature # B 1
 
    # 计算锚点和所有负样本之间的相似度
    negative_logits = torch.einsum('nc,kc->nk', [anchor_normalized, positive_normalized]) / temperature # B B
 
    # 在负样本logits中去除每个样本自己的部分，因为自己不能作为自己的负样本
    new_negative_logits = torch.zeros(negative_logits.shape[0], negative_logits.shape[1] - 1) # B (B-1)
    for i in range(negative_logits.shape[0]):
        new_negative_logits[i] = torch.cat((negative_logits[i, :i], negative_logits[i, i+1:]), dim = 0) 
 
    # 将正样本logits和负样本logits合并为logits矩阵，正样本logits为第一列
    logits = torch.cat([positive_logits, new_negative_logits], dim=1) # B (1+B-1) # 正样本分数全放在第一列，因此下面的标签为0
 
    # 创建目标标签，正样本的索引是0
    labels = torch.zeros(batch_size).to(dtype=torch.long).to(anchor_features.device)
 
    # 计算交叉熵损失
    loss = F.cross_entropy(logits, labels)
 
    return loss
 
# 第二种写法，分母包含正样本
def info_nce_loss2(anchor_features, positive_features, temperature):
    batch_size, feature_dim = anchor_features.shape # B C
 
    # L2归一化
    anchor_normalized = F.normalize(anchor_features, dim = 1) # B C
    positive_normalized = F.normalize(positive_features, dim = 1) # B C
 
    # 计算锚点和正样本之间的相似度（余弦相似度）
    positive_logits = torch.einsum('nc,nc->n', [anchor_normalized, positive_normalized]).unsqueeze(1) / temperature # B 1
 
    # 计算锚点和所有负样本之间的相似度
    negative_logits = torch.einsum('nc,kc->nk', [anchor_normalized, positive_normalized]) / temperature # B B
 
    # 将正样本logits和负样本logits合并为logits矩阵，正样本logits为第一列
    logits = torch.cat([positive_logits, negative_logits], dim=1) # B (1+B) # 正样本分数全放在第一列，因此下面的标签为0
 
    # 创建目标标签，正样本的索引是0
    labels = torch.zeros(batch_size).to(dtype=torch.long).to(anchor_features.device)
 
    # 计算交叉熵损失
    loss = F.cross_entropy(logits, labels)
 
    return loss
 
if __name__ == "__main__":
    batch_size = 32  # 批次大小
    feature_dim = 128  # 特征维度
    temperature = 0.1  # 温度参数
 
    # 假设这些特征是通过编码器生成的
    anchor_features = torch.randn(batch_size, feature_dim)
    positive_features = torch.randn(batch_size, feature_dim)
 
    # 计算InfoNCE loss
    loss1 = info_nce_loss(anchor_features, positive_features, temperature)
 
    loss2 = info_nce_loss2(anchor_features, positive_features, temperature)
    
    print("loss1: ", loss1)
    print("loss2: ", loss2)
 
    print("All Done!")