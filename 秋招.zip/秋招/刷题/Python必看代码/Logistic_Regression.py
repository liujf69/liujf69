import numpy as np
import matplotlib.pyplot as plt

# 生成二分类数据
np.random.seed(0)
num_observations = 500

# 生成正例数据 (类1)
x1 = np.random.multivariate_normal([0,0], [[1,0.75],[0.75,1]], num_observations)
y1 = np.zeros(num_observations)

# 生成负例数据 (类0)
x2 = np.random.multivariate_normal([1,4], [[1,0.75],[0.75,1]], num_observations)
y2 = np.ones(num_observations)

# 合并数据
X = np.vstack((x1, x2)).astype(np.float32)
y = np.hstack((y1, y2))

# 数据可视化
plt.figure(figsize=(10,6))
plt.scatter(X[:num_observations, 0], X[:num_observations, 1], color='red', label='Class 0')
plt.scatter(X[num_observations:, 0], X[num_observations:, 1], color='blue', label='Class 1')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.show()

def sigmoid(z):
    """Sigmoid函数"""
    return 1 / (1 + np.exp(-z))

def compute_loss(y, y_pred):
    """计算损失函数 (对数损失)"""
    m = len(y)
    loss = -1/m * np.sum(y * np.log(y_pred) + (1 - y) * np.log(1 - y_pred))
    return loss

def gradient_descent(X, y, theta, learning_rate, num_iterations):
    """梯度下降算法"""
    m = len(y)
    for i in range(num_iterations):
        # 计算预测值
        z = np.dot(X, theta)
        y_pred = sigmoid(z)
        
        # 计算梯度
        gradient = np.dot(X.T, (y_pred - y)) / m
        
        # 更新参数
        theta -= learning_rate * gradient
        
        # 每100次迭代打印损失
        if i % 100 == 0:
            loss = compute_loss(y, y_pred)
            print(f"Iteration {i}: Loss = {loss:.4f}")
            
    return theta

# 标准化特征
X = (X - np.mean(X, axis=0)) / np.std(X, axis=0)

# 增加一列偏置项
X = np.hstack((np.ones((X.shape[0], 1)), X))

# 初始化模型参数 (theta)
theta = np.zeros(X.shape[1])

# 训练模型
learning_rate = 0.1
num_iterations = 1000
theta = gradient_descent(X, y, theta, learning_rate, num_iterations)

def predict(X, theta):
    """根据模型参数进行预测"""
    return sigmoid(np.dot(X, theta)) >= 0.5

# 进行预测
predictions = predict(X, theta)

# 计算准确率
accuracy = np.mean(predictions == y)
print(f"模型的准确率: {accuracy:.2f}")
