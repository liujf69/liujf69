import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiHeadSelfAttention(nn.Module):
    def __init__(self, input_dim, num_heads, head_dim):
        super(MultiHeadSelfAttention, self).__init__()
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.input_dim = input_dim
        assert input_dim % num_heads == 0, "input_dim must be divisible by num_heads"
        
        self.query_layers = nn.ModuleList([nn.Linear(input_dim, head_dim) for _ in range(num_heads)])
        self.key_layers = nn.ModuleList([nn.Linear(input_dim, head_dim) for _ in range(num_heads)])
        self.value_layers = nn.ModuleList([nn.Linear(input_dim, head_dim) for _ in range(num_heads)])
        
        self.fc_out = nn.Linear(num_heads * head_dim, input_dim)
    
    def forward(self, x):
        # x shape: (batch_size, seq_len, input_dim)
        batch_size, seq_len, input_dim = x.size()
        
        multi_head_outputs = []
        for i in range(self.num_heads):
            # Compute Q, K, V for each head
            Q = self.query_layers[i](x)  # (batch_size, seq_len, head_dim)
            K = self.key_layers[i](x)    # (batch_size, seq_len, head_dim)
            V = self.value_layers[i](x)  # (batch_size, seq_len, head_dim)
            
            # Compute attention scores and apply softmax
            scores = torch.matmul(Q, K.transpose(-2, -1)) / torch.sqrt(torch.tensor(self.head_dim, dtype=torch.float32, device=x.device))
            weights = F.softmax(scores, dim=-1)
            
            # Compute the output for each head
            head_output = torch.matmul(weights, V)  # (batch_size, seq_len, head_dim)
            multi_head_outputs.append(head_output)
        
        # Concatenate the outputs from all heads
        concat_output = torch.cat(multi_head_outputs, dim=-1)  # (batch_size, seq_len, num_heads * head_dim)
        
        # Final linear transformation
        final_output = self.fc_out(concat_output)  # (batch_size, seq_len, input_dim)
        
        return final_output, weights

if __name__ == "__main__":
    # Example usage
    batch_size = 2
    seq_len = 5
    input_dim = 8
    num_heads = 2
    head_dim = input_dim // num_heads

    x = torch.randn(batch_size, seq_len, input_dim)

    multi_head_attention = MultiHeadSelfAttention(input_dim, num_heads, head_dim)
    output, weights = multi_head_attention(x)

    print("Output:", output)
    print("Attention Weights:", weights)