import torch
import torch.nn as nn
import torch.nn.functional as F

# 实现 self attention, multi_head attention
class Attention(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, num_head: int = 2):
        super(Attention, self).__init__()
        self.query = nn.Linear(input_dim, output_dim)
        self.key = nn.Linear(input_dim, output_dim)
        self.value = nn.Linear(input_dim, output_dim)
        self.scale = torch.sqrt(torch.FloatTensor([output_dim]))
        
        self.output_dim = output_dim
        self.num_head = num_head
        self.dim_head = output_dim // num_head
        assert output_dim % num_head == 0
        
    def forward(self, x: torch.Tensor, mask: torch.Tensor = None):
        # x.shape: (batch_size, seq_len, input_dim)
        batch_size, seq_len, input_dim = x.shape
        
        # cal q k v
        Q = self.query(x).reshape(batch_size, seq_len, self.num_head, self.dim_head).transpose(1, 2) # batchsize, num_head, seq_len, head_dim
        K = self.key(x).reshape(batch_size, seq_len, self.num_head, self.dim_head).transpose(1, 2)  # batchsize, num_head, seq_len, head_dim
        V = self.value(x).reshape(batch_size, seq_len, self.num_head, self.dim_head).transpose(1, 2)  # batchsize, num_head, seq_len, head_dim
        
        # cal scores
        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale # batchsize, num_head, seq_len, seq_len
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float("-1e20"))
        
        # softmax
        weights = F.softmax(scores, dim = -1) # batchsize, seq_len, num_head, num_head
        
        # cal output
        output = torch.matmul(weights, V) # batchsize, num_head, seq_len, head_dim
        output = output.transpose(1, 2).reshape(batch_size, seq_len, self.output_dim) # batch_size, seq_len, output_dim
        return output
    
if __name__ == "__main__":
    batch_size = 2
    seq_len = 5
    input_dim = 4
    output_dim = 8

    x = torch.randn(batch_size, seq_len, input_dim)
    # attention_mask = 1 - torch.triu(torch.ones((seq_len, seq_len)), diagonal = 1) # 自回归
    attention_mask = None
    
    attention = Attention(input_dim, output_dim)
    output = attention(x, mask = attention_mask)
    
    print("output.shape: ", output.shape)
    
    print("All Done!")