import torch
import torch.nn.functional as F


def InfoNCE_Loss(positive: torch.Tensor, negative: torch.Tensor, temperature: float):
    B, C = positive.shape
    
    positive = F.normalize(positive, dim = 1)
    negative = F.normalize(negative, dim = 1)
    
    p = torch.einsum('bc, bc -> b', [positive, negative]).unsqueeze(1) / temperature # B 1
    n = torch.einsum('bc, kc -> bk', [positive, negative]) / temperature # B B
    
    logits = torch.concat([p, n], dim = 1) # B [1+B]
    
    labels = torch.zeros(B).to(dtype=torch.long).to(n.device)
    
    loss = F.cross_entropy(logits, labels)
    
    return loss

if __name__ == "__main__":
    B = 2
    C = 3
    T = 0.1
    positive = torch.rand(B, C)
    negative = torch.rand(B, C)
    
    loss = InfoNCE_Loss(positive, negative, T)
    
    print("loss: ", loss)
    